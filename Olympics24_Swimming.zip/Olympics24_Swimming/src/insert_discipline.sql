INSERT INTO Discipline (Discipline_Code, Discipline_Name) VALUES ('artistic-swimming', 'Artistic Swimming');
INSERT INTO Discipline (Discipline_Code, Discipline_Name) VALUES ('marathon-swimming', 'Marathon Swimming');
INSERT INTO Discipline (Discipline_Code, Discipline_Name) VALUES ('diving', 'Diving');
INSERT INTO Discipline (Discipline_Code, Discipline_Name) VALUES ('water-polo', 'Water Polo');
INSERT INTO Discipline (Discipline_Code, Discipline_Name) VALUES ('swimming', 'Swimming');
INSERT INTO Discipline (Discipline_Code, Discipline_Name) VALUES ('surfing', 'Surfing');
