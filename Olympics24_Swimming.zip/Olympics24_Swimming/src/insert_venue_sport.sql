INSERT INTO Venue_Sport (Venue, Discipline_Code) VALUES ('Aquatics Centre', 'artistic-swimming');
INSERT INTO Venue_Sport (Venue, Discipline_Code) VALUES ('Aquatics Centre', 'diving');
INSERT INTO Venue_Sport (Venue, Discipline_Code) VALUES ('Aquatics Centre', 'water-polo');
INSERT INTO Venue_Sport (Venue, Discipline_Code) VALUES ('Paris La Defense Arena', 'swimming');
INSERT INTO Venue_Sport (Venue, Discipline_Code) VALUES ('Paris La Defense Arena', 'water-polo');
INSERT INTO Venue_Sport (Venue, Discipline_Code) VALUES ('Pont Alexandre III', 'marathon-swimming');
INSERT INTO Venue_Sport (Venue, Discipline_Code) VALUES ('Teahupo''o, Tahiti', 'surfing');
