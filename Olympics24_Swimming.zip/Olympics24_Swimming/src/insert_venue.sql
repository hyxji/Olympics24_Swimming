INSERT INTO Venue (Venue, Date_Start, Date_End) VALUES ('Aquatics Centre', '2024-07-27 09:00:00', '2024-08-10 20:00:00');
INSERT INTO Venue (Venue, Date_Start, Date_End) VALUES ('Paris La Defense Arena', '2024-07-27 09:00:00', '2024-08-11 13:50:00');
INSERT INTO Venue (Venue, Date_Start, Date_End) VALUES ('Pont Alexandre III', '2024-07-30 06:00:00', '2024-08-09 08:30:00');
INSERT INTO Venue (Venue, Date_Start, Date_End) VALUES ('Teahupo''o, Tahiti', '2024-07-27 17:00:00', '2024-07-31 03:15:00');
